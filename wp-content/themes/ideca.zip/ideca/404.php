<?php  get_header(); ?>
		<h1>Pagina no encontrada</h1>
		<p>Intente con el buscador del sitio ;)</p>
<?php  get_footer(); ?>