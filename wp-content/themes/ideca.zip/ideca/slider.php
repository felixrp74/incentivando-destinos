	<section class="slider">
	  <!--<div class="cycle-slideshow">
				<img src="http://lorempixel.com/g/928/300/city/1" alt="">
				<img src="http://lorempixel.com/g/928/300/city/2" alt="">
				<img src="http://lorempixel.com/g/928/300/city/3" alt="">
			</div>-->
	</section>